create function set_current_timestamp_updated_at() returns trigger
    language plpgsql
as
$$
DECLARE
    _new record;
BEGIN
    _new := NEW;
    _new."updated_at" = NOW();
    RETURN _new;
END;
$$;

alter function set_current_timestamp_updated_at() owner to postgres;

